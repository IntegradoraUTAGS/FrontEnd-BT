import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-alta-buttons',
  templateUrl: './alta-buttons.component.html',
  styleUrls: ['./alta-buttons.component.css']
})
export class AltaButtonsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
