export class RegistrarModel {
    nombre: string;
    usuario: string;
    correo: string;
    contrasena: string;
    role: string;


}