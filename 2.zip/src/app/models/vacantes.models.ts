export class vacantesModelo{
  
    public perfil:String;
    public requiere:String;
    public horario:String;
    //public carreras:String,
    public prestaciones:String;
    public dirigidoA:String;
    public dirigidoPersona:String;
    public sueldo:String;
    public idioma:String;
    public fechaLimite:String;

}