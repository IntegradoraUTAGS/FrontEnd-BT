export class UsuarioModel {
    correo: string;
    contrasena: string;
    role: string;


}